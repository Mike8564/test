# Project board template

A standalone local task board with Tasks, Workflow, Team and Channels pages.
All included names, tasks and workflow steps are generic examples. No original project records, conversations, research, credentials, logs or backups are included.

## Run

Requires Python 3.10 or newer; no external packages needed.

On macOS, double-click `Start Board.command`. Alternatively, open a terminal in this folder and run:

```sh
python3 server.py --port 8785
```

Open http://127.0.0.1:8785. Keep the terminal open. Press Control+C to stop.
The template uses a different port from the original board and stores changes only inside this copy.

## Customize

- Add or edit tasks in the interface. Existing tasks are only examples.
- Edit `data/board.json` while the server is stopped to change project information, team profiles and the workflow diagram.
- When changing team identifiers, also update `OWNERS` in `server.py`.
- Start empty by setting `tasks` to `[]` and clearing each workflow node's `task_ids`.
- Separate channels live in `data/channels/`.
- Task edits save locally and may create local backups after you begin using it.

Local access is not encryption or operating-system account isolation. The board does not start agents, send external messages, or execute tasks.
