# Project owner

Use this channel for focused task briefs and replies.
