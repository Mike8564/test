#!/usr/bin/env python3
"""Local, file-backed project board. No execution or messaging facilities."""
import argparse
import copy
import json
import os
from pathlib import Path
import re
import secrets
import shutil
import tempfile
import threading
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlsplit

ROOT = Path(__file__).resolve().parent
OWNERS = {'lead', 'builder', 'reviewer', 'owner'}
STATUSES = {'backlog', 'in_progress', 'review', 'regression', 'modify', 'blocked', 'done'}
PRIORITIES = {'P0', 'P1', 'P2', 'P3'}
DISPATCH = {'not_sent', 'prepared', 'sent', 'running', 'returned', 'accepted'}
EDITABLE = {'title', 'description', 'status', 'priority', 'assignee', 'reviewer', 'depends_on', 'acceptance', 'evidence', 'next_action', 'failure_action', 'dispatch_status'}
STRINGS = {'title', 'description', 'acceptance', 'next_action', 'failure_action'}
TASK_ID = re.compile(r'P-[0-9]+\Z')


def now():
    return datetime.now(timezone.utc).isoformat()


class Problem(Exception):
    def __init__(self, status, message):
        self.status, self.message = status, message


class BoardStore:
    def __init__(self, data_dir):
        self.root = Path(data_dir)
        self.path = self.root / 'board.json'
        self.lock = threading.RLock()

    def read(self):
        with self.lock:
            try:
                return json.loads(self.path.read_text(encoding='utf-8'))
            except (OSError, ValueError) as exc:
                raise Problem(500, f'Unable to read board: {exc}') from exc

    def atomic_write(self, path, content):
        path.parent.mkdir(parents=True, exist_ok=True)
        temp = None
        try:
            with tempfile.NamedTemporaryFile('w', encoding='utf-8', dir=path.parent, delete=False) as out:
                temp = out.name
                out.write(content)
                out.flush()
                os.fsync(out.fileno())
            os.replace(temp, path)
        finally:
            if temp and os.path.exists(temp):
                os.unlink(temp)

    def save(self, board):
        try:
            if self.path.exists():
                backup = self.root / 'backups' / 'board.previous.json'
                backup.parent.mkdir(parents=True, exist_ok=True)
                self.atomic_write(backup, self.path.read_text(encoding='utf-8'))
            self.atomic_write(self.path, json.dumps(board, indent=2, ensure_ascii=False) + '\n')
        except OSError as exc:
            raise Problem(500, f'Unable to save board: {exc}') from exc

    def check_revision(self, board, rev):
        if type(rev) is not int or rev < 0:
            raise Problem(400, 'expected_revision must be a nonnegative integer')
        if rev != board.get('revision'):
            raise Problem(409, 'Board changed; reload and try again')

    def validate(self, task, tasks, agents):
        for field in STRINGS:
            if not isinstance(task.get(field), str):
                raise Problem(400, f'{field} must be a string')
        if not task['title'].strip():
            raise Problem(400, 'title is required')
        for field, allowed in [('status', STATUSES), ('priority', PRIORITIES), ('dispatch_status', DISPATCH)]:
            if not isinstance(task.get(field), str) or task[field] not in allowed:
                raise Problem(400, f'Invalid {field}')
        available = OWNERS & {a.get('id') for a in agents if isinstance(a, dict)}
        if not isinstance(task.get('assignee'), str) or not isinstance(task.get('reviewer'), str) or task['assignee'] not in available or task['reviewer'] not in available | {''}:
            raise Problem(400, 'Invalid assignee or reviewer')
        for field in ('depends_on', 'evidence'):
            if not isinstance(task.get(field), list) or any(not isinstance(x, str) or not x.strip() for x in task[field]):
                raise Problem(400, f'{field} must be an array of nonempty strings')
        if task['status'] == 'done' and (not task['acceptance'].strip() or not task['evidence']):
            raise Problem(400, 'Done requires acceptance and evidence')
        graph = {t['id']: t.get('depends_on', []) for t in tasks}
        graph[task['id']] = task['depends_on']
        if any(dep not in graph for dep in task['depends_on']):
            raise Problem(400, 'Dependency does not exist')
        visiting, visited = set(), set()
        def visit(node):
            if node in visiting:
                raise Problem(400, 'Cyclic dependencies are not allowed')
            if node in visited:
                return
            visiting.add(node)
            for dep in graph.get(node, []):
                if dep in graph:
                    visit(dep)
            visiting.remove(node)
            visited.add(node)
        visit(task['id'])

    def update(self, rev, changes, task_id=None):
        with self.lock:
            board = self.read()
            self.check_revision(board, rev)
            if not isinstance(changes, dict) or set(changes) - EDITABLE:
                raise Problem(400, 'Unknown or invalid task fields')
            tasks = board['tasks']
            if task_id:
                task = next ( (t for t in tasks if t['id'] == task_id), None)
                if task is None:
                    raise Problem(404, 'Task not found')
                task = copy.deepcopy(task)
            else:
                number = max((int(t['id'][2:]) for t in tasks if TASK_ID.fullmatch(t.get('id', ''))), default=0) + 1
                task = dict(id=f'P-{number:03d}', title='', description='', status='backlog', priority='P2', assignee='', reviewer='', depends_on=[], acceptance='', evidence=[], next_action='', failure_action='', dispatch_status='not_sent', updates=[], created_at=now())
            task.update(changes)
            task['updated_at'] = now()
            self.validate(task, tasks, board['agents'])
            if task_id:
                board['tasks'] = [task if t['id'] == task_id else t for t in tasks]
            else:
                tasks.append(task)
            self.commit(board, f"{'Updated' if task_id else 'Created'} {task['id']}")
            return {'revision': board['revision'], 'task': task}

    def add_update(self, task_id, rev, update):
        with self.lock:
            board = self.read()
            self.check_revision(board, rev)
            task = next((t for t in board['tasks'] if t['id'] == task_id), None)
            if task is None:
                raise Problem(404, 'Task not found')
            fields = {'author', 'summary', 'success', 'issue', 'concern', 'next_owner', 'evidence'}
            if not isinstance(update, dict) or set(update) != fields:
                raise Problem(400, 'Invalid update fields')
            owners = OWNERS & {a.get('id') for a in board['agents']}
            if not isinstance(update['author'], str) or not isinstance(update['next_owner'], str) or update['author'] not in owners or update['next_owner'] not in owners:
                raise Problem(400, 'Invalid update author or next owner')
            for field in ('summary', 'success', 'issue', 'concern'):
                if not isinstance(update[field], str):
                    raise Problem(400, f'{field} must be a string')
            if not update['summary'].strip():
                raise Problem(400, 'summary is required')
            if not isinstance(update['evidence'], list) or any(not isinstance(x, str) or not x.strip() for x in update['evidence']):
                raise Problem(400, 'evidence must be an array of nonempty strings')
            note = dict(update, id=secrets.token_hex(8), at=now())
            task['updates'] = (task.get('updates', []) + [note])[-100:]
            task['updated_at'] = now()
            self.commit(board, f'Added progress report for {task_id}')
            return {'revision': board['revision'], 'task': task}

    def commit(self, board, message):
        board['revision'] += 1
        board['updated_at'] = now()
        board['activity'] = (board.get('activity', []) + [{'timestamp': board['updated_at'], 'message': message}])[-100:]
        self.save(board)

    def brief(self, task_id):
        board = self.read()
        task = next((t for t in board['tasks'] if t['id'] == task_id), None)
        if not task:
            raise Problem(404, 'Task not found')
        recipient = task['assignee']
        if recipient not in OWNERS or recipient not in {a.get('id') for a in board['agents']}:
            raise Problem(400, 'Invalid task recipient')
        evidence = '\n'.join(f'- {v}' for v in task.get('evidence', [])) or '- None supplied'
        content = (f"# {task['id']}: {task['title']}\n\n"
                   f"## Objective\n{task.get('description', '')}\n\n## Input evidence links\n{evidence}\n\n"
                   f"## Done criteria\n{task.get('acceptance', '')}\n\n"
                   f"## Constraints\nWork only within this task's scope. Prepare a report; do not claim verification without evidence.\n\n"
                   f"## Report destination\nchannels/{recipient}.md\n\n## Next owner\n{task.get('reviewer') or recipient}\n\n"
                   f"## Next action\n{task.get('next_action', '')}\n\n## Failure action\n{task.get('failure_action', '')}\n")
        return {'task_id': task_id, 'recipient': recipient, 'content': content}

    def prepare(self, task_id, rev):
        with self.lock:
            board = self.read()
            self.check_revision(board, rev)
            brief = self.brief(task_id)
            task = next(t for t in board['tasks'] if t['id'] == task_id)
            if task.get('dispatch_status') in {'running', 'accepted'}:
                raise Problem(409, 'Cannot prepare a brief while dispatch is running or accepted')
            task['dispatch_status'] = 'prepared'
            task['updated_at'] = now()
            try:
                self.atomic_write(self.root / 'briefs' / f'{task_id}.md', brief['content'])
                channel = self.root / 'channels' / f"{brief['recipient']}.md"
                old = channel.read_text(encoding='utf-8') if channel.exists() else ''
                self.atomic_write(channel, old + ('\n' if old else '') + brief['content'])
                self.commit(board, f'Prepared brief for {task_id}')
            except OSError as exc:
                raise Problem(500, f'Unable to prepare brief: {exc}') from exc
            return dict(brief, revision=board['revision'], status='prepared')


class BoardServer(ThreadingHTTPServer):
    def __init__(self, port=8770, data_dir=ROOT / 'data'):
        super().__init__(('127.0.0.1', port), Handler)
        self.store = BoardStore(data_dir)
        self.token = secrets.token_urlsafe(32)


class Handler(BaseHTTPRequestHandler):
    def log_message(self, format, *args):
        pass

    def respond(self, status, value, content_type='application/json; charset=utf-8', headers=None):
        data = json.dumps(value, ensure_ascii=False).encode() if content_type.startswith('application/json') else value
        self.send_response(status)
        self.send_header('Content-Type', content_type)
        self.send_header('Content-Length', str(len(data)))
        self.send_header('Cache-Control', 'no-store')
        self.send_header('X-Content-Type-Options', 'nosniff')
        for key, val in (headers or {}).items():
            self.send_header(key, val)
        self.end_headers()
        self.wfile.write(data)

    def security(self, mutation=False):
        port = self.server.server_port
        hosts = {f'127.0.0.1:{port}', f'localhost:{port}'}
        if self.headers.get('Host', '').lower() not in hosts:
            raise Problem(403, 'Invalid Host')
        origin = self.headers.get('Origin')
        if origin and origin.lower() not in {f'http://{host}' for host in hosts}:
            raise Problem(403, 'Invalid Origin')
        if mutation and not secrets.compare_digest(self.headers.get('X-Board-Token', ''), self.server.token):
            raise Problem(403, 'Invalid board token')

    def body(self):
        try:
            length = int(self.headers.get('Content-Length', '0'))
            if length < 1 or length > 1024 * 1024:
                raise ValueError()
            obj = json.loads(self.rfile.read(length))
            if not isinstance(obj, dict):
                raise ValueError()
            return obj
        except (ValueError, UnicodeError):
            raise Problem(400, 'Invalid JSON body')

    def handle_request(self):
        mutation = self.command in ('POST', 'PATCH')
        self.security(mutation)
        path = urlsplit(self.path).path
        store = self.server.store
        if self.command == 'GET':
            if path == '/api/health': return self.respond(200, {'ok': True})
            if path == '/api/bootstrap': return self.respond(200, {'csrf_token': self.server.token})
            if path in ('/api/board', '/api/export'):
                headers = {'Content-Disposition': 'attachment; filename="board.json"'} if path.endswith('export') else None
                return self.respond(200, store.read(), headers=headers)
            m = re.fullmatch(r'/api/channels/([a-z]+)', path)
            if m:
                agent = m.group(1)
                if agent not in OWNERS or agent not in {a.get('id') for a in store.read()['agents']}:
                    raise Problem(404, 'Channel not found')
                file = store.root / 'channels' / f'{agent}.md'
                try: content = file.read_text(encoding='utf-8') if file.exists() else ''
                except OSError as exc: raise Problem(500, f'Unable to read channel: {exc}') from exc
                return self.respond(200, {'agent_id': agent, 'content': content})
            m = re.fullmatch(r'/api/briefs/(P-[0-9]+)', path)
            if m: return self.respond(200, store.brief(m.group(1)))
            static = {'/': ('index.html', 'text/html'), '/tasks': ('index.html', 'text/html'), '/workflow': ('index.html', 'text/html'), '/team': ('index.html', 'text/html'), '/channels': ('index.html', 'text/html'), '/index.html': ('index.html', 'text/html'), '/app.js': ('app.js', 'text/javascript'), '/style.css': ('style.css', 'text/css')}
            if path in static:
                name, mime = static[path]
                try: content = (ROOT / 'web' / name).read_bytes()
                except OSError: raise Problem(404, 'Asset not found')
                return self.respond(200, content, mime + '; charset=utf-8')
        elif self.command == 'PATCH':
            m = re.fullmatch(r'/api/tasks/(P-[0-9]+)', path)
            if m:
                data = self.body()
                if set(data) != {'expected_revision', 'changes'}: raise Problem(400, 'Expected revision and changes')
                return self.respond(200, store.update(data['expected_revision'], data['changes'], m.group(1)))
        elif self.command == 'POST':
            update_match = re.fullmatch(r'/api/tasks/(P-[0-9]+)/updates', path)
            if update_match:
                data = self.body()
                if set(data) != {'expected_revision', 'update'}: raise Problem(400, 'Expected revision and update')
                return self.respond(200, store.add_update(update_match.group(1), data['expected_revision'], data['update']))
            if path == '/api/tasks':
                data = self.body()
                if set(data) != {'expected_revision', 'task'}: raise Problem(400, 'Expected revision and task')
                return self.respond(201, store.update(data['expected_revision'], data['task']))
            m = re.fullmatch(r'/api/briefs/(P-[0-9]+)', path)
            if m:
                data = self.body()
                if set(data) != {'expected_revision'}: raise Problem(400, 'Expected revision')
                return self.respond(200, store.prepare(m.group(1), data['expected_revision']))
        raise Problem(404, 'Not found')

    def dispatch(self):
        try: self.handle_request()
        except Problem as exc: self.respond(exc.status, {'error': exc.message})
        except (OSError, ValueError, KeyError, TypeError) as exc: self.respond(500, {'error': f'Board error: {exc}'})

    do_GET = do_POST = do_PATCH = dispatch


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--port', type=int, default=8785)
    parser.add_argument('--data-dir', type=Path, default=ROOT / 'data')
    args = parser.parse_args()
    server = BoardServer(args.port, args.data_dir)
    print(f'Board available at http://127.0.0.1:{server.server_port}', flush=True)
    try: server.serve_forever()
    except KeyboardInterrupt: pass
    finally: server.server_close()

if __name__ == '__main__': main()
