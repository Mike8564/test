#!/bin/zsh
set -eu
cd "$(dirname "$0")"
echo "Open http://127.0.0.1:8785 in your browser. Keep this window open."
python3 server.py --port 8785
