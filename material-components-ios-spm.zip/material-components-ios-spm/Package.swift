// swift-tools-version:5.9
import PackageDescription

let package = Package(
    name: "MaterialComponents",
    defaultLocalization: "en",
    platforms: [
        .iOS(.v15)
    ],
    products: [
        .library(name: "MaterialComponents", targets: ["MaterialComponents"]),
        .library(name: "MDFInternationalization", targets: ["MDFInternationalization"]),
        .library(name: "MDFTextAccessibility", targets: ["MDFTextAccessibility"]),
        .library(name: "MotionAnimator", targets: ["MotionAnimator"]),
        .library(name: "MotionInterchange", targets: ["MotionInterchange"]),
    ],
    targets: [
        .target(
            name: "MDFInternationalization",
            path: "Sources/MDFInternationalization",
            publicHeadersPath: "include",
            cSettings: [
                .headerSearchPath("include"),
                .headerSearchPath("."),
            ],
            linkerSettings: [
                .linkedFramework("UIKit"),
                .linkedFramework("CoreGraphics"),
            ]
        ),
        .target(
            name: "MDFTextAccessibility",
            path: "Sources/MDFTextAccessibility",
            exclude: [
                "include/private",
            ],
            publicHeadersPath: "include",
            cSettings: [
                .headerSearchPath("include"),
                .headerSearchPath("."),
                .headerSearchPath("private"),
            ],
            linkerSettings: [
                .linkedFramework("UIKit"),
                .linkedFramework("CoreGraphics"),
            ]
        ),
        .target(
            name: "MotionInterchange",
            path: "Sources/MotionInterchange",
            publicHeadersPath: "include",
            cSettings: [
                .headerSearchPath("include"),
                .headerSearchPath("."),
            ],
            linkerSettings: [
                .linkedFramework("QuartzCore"),
            ]
        ),
        .target(
            name: "MotionAnimator",
            dependencies: ["MotionInterchange"],
            path: "Sources/MotionAnimator",
            exclude: [
                "include/private",
            ],
            publicHeadersPath: "include",
            cSettings: [
                .headerSearchPath("include"),
                .headerSearchPath("."),
                .headerSearchPath("private"),
                .headerSearchPath("../header-maps"),
            ],
            linkerSettings: [
                .linkedFramework("UIKit"),
                .linkedFramework("QuartzCore"),
            ]
        ),
        .target(
            name: "MaterialComponents",
            dependencies: [
                "MDFInternationalization",
                "MDFTextAccessibility",
                "MotionAnimator",
                "MotionInterchange",
            ],
            path: "Sources/MaterialComponents",
            exclude: [
                "include/private",
                "components/private/Snapshot",
            ],
            resources: [
                .copy("Resources/Chips.bundle"),
                .copy("Resources/MaterialActionSheet.bundle"),
                .copy("Resources/MaterialActivityIndicator.bundle"),
                .copy("Resources/MaterialAppBar.bundle"),
                .copy("Resources/MaterialCollectionCells.bundle"),
                .copy("Resources/MaterialCollections.bundle"),
                .copy("Resources/MaterialDialogs.bundle"),
                .copy("Resources/MaterialPageControl.bundle"),
                .copy("Resources/MaterialProgressView.bundle"),
                .copy("Resources/MaterialSnackbar.bundle"),
                .copy("Resources/MaterialTextFields.bundle"),
                .process("Resources/MaterialIcons_ic_arrow_back.xcassets"),
                .process("Resources/MaterialIcons_ic_check.xcassets"),
                .process("Resources/MaterialIcons_ic_check_circle.xcassets"),
                .process("Resources/MaterialIcons_ic_chevron_right.xcassets"),
                .process("Resources/MaterialIcons_ic_color_lens.xcassets"),
                .process("Resources/MaterialIcons_ic_feedback.xcassets"),
                .process("Resources/MaterialIcons_ic_help_outline.xcassets"),
                .process("Resources/MaterialIcons_ic_info.xcassets"),
                .process("Resources/MaterialIcons_ic_more_horiz.xcassets"),
                .process("Resources/MaterialIcons_ic_radio_button_unchecked.xcassets"),
                .process("Resources/MaterialIcons_ic_reorder.xcassets"),
                .process("Resources/MaterialIcons_ic_settings.xcassets"),
            ],
            publicHeadersPath: "include",
            cSettings: [
                .headerSearchPath("include"),
                .headerSearchPath("."),
                .headerSearchPath("../header-maps"),
                .headerSearchPath("../header-maps/MotionInterchange"),
                .headerSearchPath("../header-maps/MotionAnimator"),
                .headerSearchPath("../header-maps/MDFInternationalization"),
                .headerSearchPath("../header-maps/MDFTextAccessibility"),
                .unsafeFlags([
                    "-Wno-deprecated-declarations",
                    "-Wno-availability",
                    "-Wno-nullability-completeness",
                ]),
            ],
            linkerSettings: [
                .linkedFramework("UIKit"),
                .linkedFramework("CoreGraphics"),
                .linkedFramework("CoreText"),
                .linkedFramework("QuartzCore"),
                .linkedFramework("CoreImage"),
            ]
        ),
    ]
)
