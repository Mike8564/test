# MaterialComponents (local Swift package)

Local SPM snapshot of Material Components for iOS, packaged for Xcode 27.

- Platform: **iOS 15+**
- Product: `MaterialComponents`
- Also vendors `MDFInternationalization`, `MDFTextAccessibility`, `MotionAnimator`, and `MotionInterchange`

## Add to an app

1. Remove `pod 'MaterialComponents'` (and MDF/Motion pods pulled in by it).
2. In Xcode: File → Add Package Dependencies → Add Local… → select this folder.
3. Link the `MaterialComponents` library to your app target.
4. Add `-ObjC` to the app target *Other Linker Flags* so Objective-C categories load.

Swift import:

```swift
import MaterialComponents

let message = MDCSnackbarMessage()
```

CocoaPods exposed extra Swift modules such as `MaterialComponents.MaterialSnackbar`. This package is one module, so those dotted imports are gone. The types are the same (`MDCSnackbarMessage`, `MDCButton`, …).

Objective-C:

```objc
#import <MaterialComponents/MaterialButtons.h>
```

## Notes

- `M3CTextField` Swift sources are omitted (they were not in the CocoaPods podspec).
- Examples and tests are omitted.
- Icon asset catalogs are processed into the package module bundle.
- Localization `.bundle` folders are copied by name so existing lookup code still works.
