#ifndef MDC_SPM_MATERIALPROGRESSVIEWSTRINGS_H_
#define MDC_SPM_MATERIALPROGRESSVIEWSTRINGS_H_

// Copyright 2020-present the Material Components for iOS authors. All Rights Reserved.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// clang-format off
// NOLINTBEGIN

// GENERATED CODE: DO NOT EDIT BY HAND
// GENERATED FROM: components/ProgressView/src/MaterialProgressView.bundle/Resources/en.lproj/MaterialProgressView.strings

typedef enum {
  kStr_MaterialProgressViewAccessibilityLabel = 0,
} MaterialProgressViewStringId;

// NOLINTEND
// clang-format on

#endif  // MDC_SPM_MATERIALPROGRESSVIEWSTRINGS_H_
