#ifndef MDC_SPM_M3CVISUALBACKGROUNDVIEW_H_
#define MDC_SPM_M3CVISUALBACKGROUNDVIEW_H_

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

/**
 Used to handle shadow animations of a @c M3CButton.
 */
@interface M3CVisualBackgroundView : UIView
@end

NS_ASSUME_NONNULL_END

#endif  // MDC_SPM_M3CVISUALBACKGROUNDVIEW_H_
