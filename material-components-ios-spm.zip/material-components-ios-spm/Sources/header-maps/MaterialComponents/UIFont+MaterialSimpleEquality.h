#ifndef MDC_SPM_UIFONT_MATERIALSIMPLEEQUALITY_H_
#define MDC_SPM_UIFONT_MATERIALSIMPLEEQUALITY_H_

// Copyright 2018-present the Material Components for iOS authors. All Rights Reserved.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#import <UIKit/UIKit.h>

/**
 This UIFont category provides a shallow equality check. http://www.openradar.appspot.com/28406766
 */
@interface UIFont (MaterialSimpleEquality)

/*
 Checks simple characteristics: name, weight, pointsize, traits.

 While the actual implementation of UIFont's isEqual: is not known, it is believed that
 isSimplyEqual: is more 'shallow' than isEqual:.
 */
- (BOOL)mdc_isSimplyEqual:(UIFont*)font;

@end

#endif  // MDC_SPM_UIFONT_MATERIALSIMPLEEQUALITY_H_
