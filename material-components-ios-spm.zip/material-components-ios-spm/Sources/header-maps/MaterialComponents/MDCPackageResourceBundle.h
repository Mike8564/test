#ifndef MDC_SPM_MDCPACKAGERESOURCEBUNDLE_H_
#define MDC_SPM_MDCPACKAGERESOURCEBUNDLE_H_

// Generated for Swift Package Manager resource lookup.
#import <Foundation/Foundation.h>

NS_INLINE NSBundle *MDCPackageResourceBundle(Class fallbackClass) {
#if SWIFT_PACKAGE
  NSBundle *packageBundle = SWIFTPM_MODULE_BUNDLE;
  if (packageBundle != nil) {
    return packageBundle;
  }
#endif
  NSBundle *bundle = [NSBundle bundleForClass:fallbackClass];
  return bundle ?: [NSBundle mainBundle];
}

#endif  // MDC_SPM_MDCPACKAGERESOURCEBUNDLE_H_
