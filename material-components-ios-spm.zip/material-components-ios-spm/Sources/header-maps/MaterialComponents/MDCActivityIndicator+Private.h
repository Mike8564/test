#ifndef MDC_SPM_MDCACTIVITYINDICATOR_PRIVATE_H_
#define MDC_SPM_MDCACTIVITYINDICATOR_PRIVATE_H_

// Copyright 2015-present the Material Components for iOS authors. All Rights Reserved.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#import "MDCActivityIndicator+Interface.h"

/*
 States for the internal state machine. The states represent the last animation completed.
 It provides information required to select the next animation.
 */
typedef NS_ENUM(NSInteger, MDCActivityIndicatorState) {
  MDCActivityIndicatorStateIndeterminate,
  MDCActivityIndicatorStateTransitionToDeterminate,
  MDCActivityIndicatorStateDeterminate,
  MDCActivityIndicatorStateTransitionToIndeterminate,
};

@interface MDCActivityIndicator (Private)

/**
 * Called when a stroke rotation cycle is finished.
 */
- (void)strokeRotationCycleFinishedFromState:(MDCActivityIndicatorState)state;

@end

#endif  // MDC_SPM_MDCACTIVITYINDICATOR_PRIVATE_H_
