#ifndef MDC_SPM_MATERIALTABS_H_
#define MDC_SPM_MATERIALTABS_H_

// Copyright 2016-present the Material Components for iOS authors. All Rights Reserved.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#import "MDCTabBar.h"  // IWYU pragma: keep
#import "MDCTabBarAlignment.h"  // IWYU pragma: keep
#import "MDCTabBarControllerDelegate.h"  // IWYU pragma: keep
#import "MDCTabBarDelegate.h"  // IWYU pragma: keep
#import "MDCTabBarIndicatorAttributes.h"  // IWYU pragma: keep
#import "MDCTabBarIndicatorContext.h"  // IWYU pragma: keep
#import "MDCTabBarIndicatorTemplate.h"  // IWYU pragma: keep
#import "MDCTabBarItemAppearance.h"  // IWYU pragma: keep
#import "MDCTabBarUnderlineIndicatorTemplate.h"  // IWYU pragma: keep
#import "MDCTabBarViewController.h"  // IWYU pragma: keep

#endif  // MDC_SPM_MATERIALTABS_H_
