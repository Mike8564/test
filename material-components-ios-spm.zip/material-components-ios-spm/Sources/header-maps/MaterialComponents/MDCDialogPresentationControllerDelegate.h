#ifndef MDC_SPM_MDCDIALOGPRESENTATIONCONTROLLERDELEGATE_H_
#define MDC_SPM_MDCDIALOGPRESENTATIONCONTROLLERDELEGATE_H_

// Copyright 2020-present the Material Components for iOS authors. All Rights Reserved.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#import <UIKit/UIKit.h>

@class MDCDialogPresentationController;

/**
 MDCDialogPresentationControllerDelegate provides a method that allows a delegate of an
 MDCDialogPresentationController to respond to its dismissals.
 */
NS_SWIFT_UI_ACTOR
@protocol MDCDialogPresentationControllerDelegate <NSObject>
@optional
/**
 This method allows a delegate conforming to MDCDialogPresentationControllerDelegate to respond to
 MDCDialogPresentationController dismissals after they happen.
 */
- (void)dialogPresentationControllerDidDismiss:
    (nonnull MDCDialogPresentationController *)dialogPresentationController;

/**
 This method allows a delegate conforming to MDCDialogPresentationControllerDelegate to prevent a
 dismissal if desired. If this method is left unimplemented, or implemented to return YES, the
 dismissal will go on as usual. If this method returns NO, the dismissal will not go forward.
 */
- (BOOL)dialogPresentationControllerShouldDismiss:
    (nonnull MDCDialogPresentationController *)dialogPresentationController;

/**
 This method allows a delegate conforming to MDCDialogPresentationControllerDelegate to respond to
 MDCDialogPresentationController dismissals before they happen.
 */
- (void)dialogPresentationControllerWillDismiss:
    (nonnull MDCDialogPresentationController *)dialogPresentationController;
@end

#endif  // MDC_SPM_MDCDIALOGPRESENTATIONCONTROLLERDELEGATE_H_
