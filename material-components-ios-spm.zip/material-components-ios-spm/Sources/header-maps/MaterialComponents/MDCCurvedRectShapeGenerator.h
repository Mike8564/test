#ifndef MDC_SPM_MDCCURVEDRECTSHAPEGENERATOR_H_
#define MDC_SPM_MDCCURVEDRECTSHAPEGENERATOR_H_

// Copyright 2017-present the Material Components for iOS authors. All Rights Reserved.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#import <CoreGraphics/CoreGraphics.h>
#import <Foundation/Foundation.h>

#import "MaterialShapes.h"

API_DEPRECATED_BEGIN("🤖👀 Use explicit mask layers and shape paths instead. "
                     "This has go/material-ios-migrations#scriptable-potential 🤖👀.",
                     ios(12, 12))

/**
 A curved rectangle shape generator.
 */
@interface MDCCurvedRectShapeGenerator : NSObject <MDCShapeGenerating>

/**
 The size of the curved corner.
 */
@property(nonatomic, assign) CGSize cornerSize;

/**
 Initializes an MDCCurvedRectShapeGenerator instance with a given cornerSize.
 */
- (instancetype)initWithCornerSize:(CGSize)cornerSize NS_DESIGNATED_INITIALIZER;

@end

API_DEPRECATED_END

#endif  // MDC_SPM_MDCCURVEDRECTSHAPEGENERATOR_H_
